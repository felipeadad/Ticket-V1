const { ActionRowBuilder, ButtonBuilder, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ApplicationCommand, ApplicationCommandType, SelectMenuBuilder, StringSelectMenuBuilder } = require("discord.js")
const { owner } = require("../../config.json")
const { General } = require("../../DataBaseJson/index")

module.exports = {
    name: `ticket`,
    description: `[Staff] Set ticket panel`,
    type: ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {
        if (interaction.user.id !== owner) { interaction.reply({ embeds: [new EmbedBuilder().setAuthor({ name: `Você não tem permissão para fazer isso.`, iconURL: "https://cdn.discordapp.com/emojis/1248474741170376704.png?size=2048" }).setColor("#313338")], ephemeral: true }); return; }

        await interaction.reply({ embeds: [new EmbedBuilder().setAuthor({ name: `Ticket enviado com êxito.`, iconURL: "https://cdn.discordapp.com/emojis/1248015639428333599.png?size=2048" }).setColor("#313338")], ephemeral: true })

        const embedOpen = new EmbedBuilder()
        .setAuthor({ name: `${General.get("ticket.title") === "" ? "Ticket" : `${General.get("ticket.title")}`}`, iconURL: client.user.displayAvatarURL() })
        .setDescription(`${General.get("ticket.description") === "" ? "Descrição não definida." : `${General.get("ticket.description")}`}`)
        .setColor("#313338")
        .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
        .setTimestamp()

        if (General.get("ticket.miniatura")) {
            embedOpen.setThumbnail(`${General.get("ticket.miniatura")}`)
        }

        if (General.get("ticket.banner")) {
            embedOpen.setImage(`${General.get("ticket.banner")}`)
        }

        const ticketStyle = General.get("ticket.button.color") === "" ? `Azul` : `${General.get("ticket.button.color")}`

        const rowButtonOpen = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder().setCustomId(`openTicket`).setLabel(`${General.get("ticket.button.name")}`).setStyle(ticketStyle.replace("Azul", "Primary").replace("Cinza", "Secondary").replace("Verde", "Success").replace("Vermelho", "Danger"))
            )

            if (General.get("ticket.button.emoji")) {
                rowButtonOpen.components[0].setEmoji(General.get("ticket.button.emoji"))
            }

        interaction.channel.send({
            embeds: [embedOpen],
            components: [rowButtonOpen]
        })
    }
}