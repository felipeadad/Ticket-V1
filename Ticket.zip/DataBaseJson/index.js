const {
  JsonDatabase,
} = require("wio.db");

const General = new JsonDatabase({
  databasePath: "./DatabaseJson/dbPanel.json"
});

const TicketOpen = new JsonDatabase({
  databasePath: "./DatabaseJson/ticketOpen.json"
})


module.exports = {
  General,
  TicketOpen
}