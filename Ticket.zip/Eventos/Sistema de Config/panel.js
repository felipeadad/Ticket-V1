const { EmbedBuilder, ButtonBuilder, ActionRowBuilder, ApplicationCommandType, isStringSelectMenu, StringSelectMenuBuilder, ChannelSelectMenuBuilder, ChannelType, RoleSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require("discord.js")
const { General } = require("../../DataBaseJson/index")
const { owner } = require("../../config.json")
const { panel } = require("../../Functions/panel")
const { gerenciarTicket } = require("../../Functions/gerenciarTicket")
const { gerenciarCanais } = require("../../Functions/gerenciarCanais")
const { gerenciarCargos } = require("../../Functions/gerenciarCargos")
const { gerenciarPayments } = require("../../Functions/gerenciarPayments")

module.exports = {
    name: "interactionCreate",
    run: async(interaction, client, message) => {

        if (interaction.isStringSelectMenu() && interaction.customId === "panelSelectMenu") {
            const option = interaction.values[0];
            if (option === "sistemaOnOff") {
                if (General.get("sistema") == true) {
                General.set("sistema", false)
                panel(client, interaction)
                } else if (General.get("sistema") == false) {
                    General.set("sistema", true)
                    panel(client, interaction)
                }
            }

            if (option === "gerenciarTicket") {
                gerenciarTicket(client, interaction)
            }

            if (option === "gerenciarCanais") {
                gerenciarCanais(client, interaction)
            }

            if (option === "gerenciarCargos") {
                gerenciarCargos(client, interaction)
            }

            if (option === "gerenciarPayments") {
                gerenciarPayments(client, interaction)
            }
        }

        if (interaction.isChannelSelectMenu() && interaction.customId === "channelLogsSelect") {
            const option = interaction.values[0]

            General.set("channelLogs", option);
            gerenciarCanais(client, interaction);
        }

        if (interaction.isChannelSelectMenu() && interaction.customId === "channelFeedbacksSelect") {
            const option = interaction.values[0]

            General.set("channelFeedbacks", option);
            gerenciarCanais(client, interaction);
        }

        if (interaction.isButton() && interaction.customId === "changeChannelLogs") {
            interaction.update({
                embeds: [
                    new EmbedBuilder()
                    .setAuthor({ name: `Red Apps Ticket`, iconURL: client.user.displayAvatarURL() })
                    .setDescription(`- **Selecione abaixo qual canal você deseja configurar:**`)
                    .addFields(
                        {
                            name: `Channel Logs`, value: `${General.get("channelLogs") === "" ? "\`Não definido.\`" : interaction.guild.channels.cache.get(General.get("channelLogs"))}`, inline: true
                        },
                        {
                            name: `Channel Feedbacks`, value: `${General.get("channelFeedbacks") === "" ? "\`Não definido.\`" : interaction.guild.channels.cache.get(General.get("channelFeedbacks"))}`, inline: true
                        }
                    )
                    .setColor("#313338")
                    .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
                    .setTimestamp()
                ],
                components: [
                    new ActionRowBuilder()
                    .addComponents(
                        new ChannelSelectMenuBuilder()
                        .setCustomId(`channelLogsSelect`)
                        .setPlaceholder(`Clique aqui para selecionar uma opção`)
                        .setMaxValues(1)
                        .setChannelTypes(ChannelType.GuildText)
                    ),
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder().setCustomId(`voltarCanais`).setLabel(`Voltar`).setEmoji(`1247222436533899264`).setStyle(2)
                    )
                ]
            })
        }

        if (interaction.isButton() && interaction.customId === "changeChannelFeedbacks") {
            interaction.update({
                embeds: [
                    new EmbedBuilder()
                    .setAuthor({ name: `Red Apps Ticket`, iconURL: client.user.displayAvatarURL() })
                    .setDescription(`- **Selecione abaixo qual canal você deseja configurar:**`)
                    .addFields(
                        {
                            name: `Channel Logs`, value: `${General.get("channelLogs") === "" ? "\`Não definido.\`" : interaction.guild.channels.cache.get(General.get("channelLogs"))}`, inline: true
                        },
                        {
                            name: `Channel Feedback`, value: `${General.get("channelFeedbacks") === "" ? "\`Não definido.\`" : interaction.guild.channels.cache.get(General.get("channelFeedbacks"))}`, inline: true
                        }
                    )
                    .setColor("#313338")
                    .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
                    .setTimestamp()
                ],
                components: [
                    new ActionRowBuilder()
                    .addComponents(
                        new ChannelSelectMenuBuilder()
                        .setCustomId(`channelFeedbacksSelect`)
                        .setPlaceholder(`Clique aqui para selecionar uma opção`)
                        .setMaxValues(1)
                        .setChannelTypes(ChannelType.GuildText)
                    ),
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder().setCustomId(`voltarCanais`).setLabel(`Voltar`).setEmoji(`1247222436533899264`).setStyle(2)
                    )
                ]
            })
        }

        if (interaction.isButton() && interaction.customId === "changeCargoStaff") {
            interaction.update({
                embeds: [
                    new EmbedBuilder()
                    .setAuthor({ name: `Red Apps Ticket`, iconURL: client.user.displayAvatarURL() })
                    .setDescription(`- **Selecione abaixo qual canal você deseja configurar:**`)
                    .addFields(
                        {
                            name: `Cargo Staff`, value: `${General.get("cargoSuportt") === "" ? "\`Não definido.\`" : interaction.guild.roles.cache.get(General.get("cargoSuportt"))}`, inline: true
                        },
                        {
                            name: `Cargo Intermediador`, value: `\`Em Breve (V2)\``, inline: true
                        }
                    )
                    .setColor("#313338")
                    .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
                    .setTimestamp()
                ],
                components: [
                    new ActionRowBuilder()
                    .addComponents(
                        new RoleSelectMenuBuilder()
                        .setCustomId(`changeCargoStaffSelect`)
                        .setPlaceholder(`Clique aqui para selecionar uma opção`)
                        .setMaxValues(1)
                    ),
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder().setCustomId(`voltarCargos`).setLabel(`Voltar`).setEmoji(`1247222436533899264`).setStyle(2)
                    )
                ]
            })
        }

        if (interaction.isButton() && interaction.customId === "changePaymentsOnOff") {
            if (General.get("payments.sistema") === true) {
                General.set("payments.sistema", false)
                gerenciarPayments(client, interaction)
            } else if (General.get("payments.sistema") === false) {
                General.set("payments.sistema", true)
                gerenciarPayments(client, interaction)
            }
        }

        if (interaction.isButton() && interaction.customId === "changePix") {

            const modal = new ModalBuilder()
            .setCustomId(`modalChavePix`)
            .setTitle(`Alterar Chave Pix`)

            const option1 = new TextInputBuilder()
            .setCustomId(`chavePix`)
            .setLabel(`Sua Chave Pix:`)
            .setPlaceholder(`Coloque sua chave pix aqui`)
            .setStyle(TextInputStyle.Short)
            .setMaxLength(350)
            .setRequired(true)

            const optionx1 = new ActionRowBuilder().addComponents(option1)

            modal.addComponents(optionx1)
            await interaction.showModal(modal)
        }

        if (interaction.isModalSubmit() && interaction.customId === "modalChavePix") {
            const optionx1 = interaction.fields.getTextInputValue("chavePix")

            General.set("payments.pix", optionx1);
            gerenciarPayments(client, interaction);
        }

        if (interaction.isButton() && interaction.customId === "changeQrCode") {

            const modal = new ModalBuilder()
            .setCustomId(`modalQrCode`)
            .setTitle(`Alterar Qr Code`)

            const option1 = new TextInputBuilder()
            .setCustomId(`qrCode`)
            .setLabel(`Seu URL Qr Code:`)
            .setPlaceholder(`https://`)
            .setStyle(TextInputStyle.Short)
            .setMaxLength(500)
            .setRequired(true)

            const optionx1 = new ActionRowBuilder().addComponents(option1)

            modal.addComponents(optionx1)
            await interaction.showModal(modal)
        }

        if (interaction.isModalSubmit() && interaction.customId === "modalQrCode") {
            const optionx1 = interaction.fields.getTextInputValue("qrCode")

            function link(n) {
                const urlRegex = /^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/;
                return urlRegex.test(n)
              }

            if (!link(optionx1)) return interaction.reply({ embeds: [new EmbedBuilder().setAuthor({ name: `A URL do banner está inválida, tente novamente usando uma URL válida.`, iconURL: "https://cdn.discordapp.com/emojis/1248474741170376704.png?size=2048" }).setColor("#313338")], ephemeral: true })

            General.set("payments.qrcode");
            gerenciarPayments(client, interaction);
        }

        if (interaction.isRoleSelectMenu() && interaction.customId === "changeCargoStaffSelect") {
            const option = interaction.values[0]

            General.set("cargoSuportt", option);
            gerenciarCargos(client, interaction);
        }
        
        if (interaction.isButton() && interaction.customId === "voltarPanel") {
            panel(client, interaction);
        }

        if (interaction.isButton() && interaction.customId === "voltarCanais") {
            gerenciarCanais(client, interaction);
        }

        if (interaction.isButton() && interaction.customId === "voltarCargos") {
            gerenciarCargos(client, interaction);
        }

    }
}