const Discord = require("discord.js")
const { EmbedBuilder, ButtonBuilder, ActionRowBuilder, ApplicationCommandType, isStringSelectMenu, ChannelType } = require("discord.js")
const { General, TicketOpen } = require("../../DataBaseJson/index")
const { owner } = require("../../config.json")
const { panel } = require("../../Functions/panel")
const { gerenciarTicket } = require("../../Functions/gerenciarTicket")
const { gerenciarCanais } = require("../../Functions/gerenciarCanais")
const moment = require("moment")

module.exports = {
    name: "interactionCreate",
    run: async (interaction, client, message) => {

        if (interaction.isButton() && interaction.customId === "assumirTicket") {
            if (!interaction.member.roles.cache.has(General.get("cargoSuportt"))) {
                interaction.reply({ embeds: [new EmbedBuilder().setAuthor({ name: `Espere! Apenas um staff pode usar isso.`, iconURL: "https://cdn.discordapp.com/emojis/1248474741170376704.png?size=2048" }).setColor("#313338")], ephemeral: true });
                return;
            }
            if (TicketOpen.get(`${interaction.channel.id}.staff`)) {
                interaction.reply({ embeds: [new EmbedBuilder().setAuthor({ name: `Espere! Algum staff assumiu este ticket primeiro que você!`, iconURL: "https://cdn.discordapp.com/emojis/1248474741170376704.png?size=2048" }).setColor("#313338")], ephemeral: true });
                return;
            }
            TicketOpen.set(`${interaction.channel.id}.staff`, interaction.user.id);
            const descriptionTicketDentro = General.get("ticketDentro.description") === "" ? "\`\`\`Descrição não definida.\`\`\`" : `${General.get("ticketDentro.description")}`

            const ticketAberto = new EmbedBuilder()
                .setAuthor({ name: `${General.get("ticketDentro.title") === "" ? "Ticket" : `${General.get("ticketDentro.title")}`}`, iconURL: client.user.displayAvatarURL() })
                .setDescription(descriptionTicketDentro.replace("#ID", interaction.channel.id).replace("#STAFF", `${TicketOpen.get(`${interaction.channel.id}.staff`) === null ? "\`Nenhum staff assumiu ainda.\`" : `<@${TicketOpen.get(`${interaction.channel.id}.staff`)}>`}`).replace("#USER", `<@${TicketOpen.get(`${interaction.channel.id}.userOpen`)}>`))
                .setColor("#313338")
                .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
                .setTimestamp()

            if (General.get("ticketDentro.miniatura")) {
                ticketAberto.setThumbnail(`${General.get("ticketDentro.miniatura")}`)
            }

            if (General.get("ticketDentro.banner")) {
                ticketAberto.setImage(`${General.get("ticketDentro.banner")}`)
            }

            const rowTicketAberto = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder().setCustomId(`assumirTicket`).setLabel(`Assumir Ticket`).setEmoji(`1247222480179957800`).setStyle(General.get("assumirTicket") === true ? 3 : 1),
                    new ButtonBuilder().setCustomId(`pokarUser`).setLabel(`Notificar Usuário`).setEmoji(`1247223445121667155`).setStyle(1)
                )

            if (General.get("payments.sistema") === true) {
                rowTicketAberto.addComponents(
                    new ButtonBuilder()
                        .setCustomId(`paymentTicket`)
                        .setLabel(`Realizar Pix`)
                        .setEmoji(`1247222426383683666`)
                        .setStyle(1)
                        .setDisabled(General.get("payments.pix") && General.get("payments.qrcode") === "" ? false : true)
                )
            }

            rowTicketAberto.addComponents(
                new ButtonBuilder().setCustomId(`fecharTicket`).setEmoji(`1247222358733885550`).setStyle(2)
            );
    
            const cargoPerm = General.get("cargoSuportt");
            const contentTopic = cargoPerm ? `${interaction.user} | <@&${cargoPerm}>` : `${interaction.user}`;
            await interaction.update({
                content: contentTopic,
                embeds: [ticketAberto],
                components: [rowTicketAberto]
            })
            interaction.isButton({ embeds: [new EmbedBuilder().setAuthor({ name: `Você assumiu este ticket com êxito.`, iconURL: "https://cdn.discordapp.com/emojis/1247222480179957800.png?size=2048" }).setColor("#313338")], ephemeral: true })
        }

        if (interaction.isButton() && interaction.customId === "pokarUser") {
            if (!interaction.member.roles.cache.has(General.get("cargoSuportt"))) {
                interaction.reply({ embeds: [new EmbedBuilder().setAuthor({ name: `Espere! Apenas um staff pode usar isso.`, iconURL: "https://cdn.discordapp.com/emojis/1248474741170376704.png?size=2048" }).setColor("#313338")], ephemeral: true });
                return;
            }

            const threadId = interaction.channel.id;
            const userId = TicketOpen.get(threadId).userOpen;

            const user = client.users.cache.get(userId);
            interaction.reply({ embeds: [new EmbedBuilder().setAuthor({ name: `Usuário notificado com êxito.`, iconURL: "https://cdn.discordapp.com/emojis/1247222480179957800.png?size=2048" }).setColor("#313338")], ephemeral: true })
            if (user) {
                user.send({
                    embeds: [new EmbedBuilder().setAuthor({ name: `Tem um staff te chamando no seu ticket do servidor "${interaction.guild.name}"`, iconURL: "https://cdn.discordapp.com/emojis/1248477384957497504.png?size=2048" }).setColor("#313338")],
                    components: [
                        new ActionRowBuilder()
                            .addComponents(
                                new ButtonBuilder()
                                    .setURL(`https://discord.com/channels/${interaction.guild.id}/${threadId}`)
                                    .setLabel(`・Ir para o Ticket`)
                                    .setStyle(5)
                            )
                    ],
                    ephemeral: true
                });
            }
        }

        if (interaction.isButton() && interaction.customId === "fecharTicket") {
            if (!interaction.member.roles.cache.has(General.get("cargoSuportt"))) {
                interaction.reply({ embeds: [new EmbedBuilder().setAuthor({ name: `Espere! Apenas um staff pode usar isso.`, iconURL: "https://cdn.discordapp.com/emojis/1248474741170376704.png?size=2048" }).setColor("#313338")], ephemeral: true });
                return;
            }
            
            const tempTicket = `<t:${Math.floor(moment().toDate().getTime() / 1000)}:f> (<t:${Math.floor(moment().toDate().getTime() / 1000)}:R>)`;

            const channelLogsPriv = interaction.guild.channels.cache.get(General.get(`channelLogs`));
            if (channelLogsPriv) {
                await channelLogsPriv.send({
                    embeds: [
                        new EmbedBuilder()
                        .setAuthor({ name: `Ticket Finalizado`, iconURL: "https://cdn.discordapp.com/emojis/1248436294552518727.png?size=2048" })
                        .setDescription(`- **Informações:**\n - **ID DO TICKET FECHADO:** \`${interaction.channel.id}\`\n - **QUEM ABRIU O TICKET:** <@${TicketOpen.get(`${interaction.channel.id}.userOpen`)}>\n - **QUEM ASSUMIU O TICKET:** ${TicketOpen.get(`${interaction.channel.id}.staff`) === null ? "\`Nenhum staff assumiu o Ticket.\`" : `<@${TicketOpen.get(`${interaction.channel.id}.staff`)}>`}\n - **DATA E HORÀRIO:** ${tempTicket}`)
                        .setColor("#313338")
                        .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
                        .setTimestamp()
                    ]
                });
            };
            const threadId = interaction.channel.id;
            const userId = TicketOpen.get(threadId).userOpen;
            const user = client.users.cache.get(userId);
            if (General.get("channelFeedbacks")) {
                const feedbackmsg = await user.send({
                    embeds: [
                        new EmbedBuilder()
                        .setAuthor({ name: `Atendimento Finalizado`, iconURL: "https://cdn.discordapp.com/emojis/1248480003755081803.png?size=2048" })
                        .setDescription(`- Olá, nos botões abaixo você pode avaliar como foi seu atendimento com os staffs da ${interaction.guild.name}`)
                        .setColor("#313338")
                        .setFooter({ text: `Você tem 2 minutos para avaliar o atendimento`, iconURL: interaction.guild.iconURL() })
                        .setTimestamp()
                    ],
                    components: [
                        new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`1de3`).setLabel(`1/3`).setEmoji(`1248148815039696932`).setStyle(4),
                            new ButtonBuilder().setCustomId(`2de3`).setLabel(`2/3`).setEmoji(`1248148815039696932`).setStyle(4),
                            new ButtonBuilder().setCustomId(`3de3`).setLabel(`3/3`).setEmoji(`1248148815039696932`).setStyle(4)
                        )
                    ],
                    ephemeral: true
                });
                setTimeout(() => {
                    feedbackmsg.edit({ embeds: [new EmbedBuilder().setAuthor({ name: `O tempo para avaliar expirou.`, iconURL: "https://cdn.discordapp.com/emojis/1247222476967247963.png?size=2048" }).setColor("#313338")], components: [] })
                    const channelFeedbacks = interaction.client.channels.cache.get(General.get(`channelFeedbacks`));
                    if (channelFeedbacks) {
                        channelFeedbacks.send({
                            embeds: [
                                new EmbedBuilder()
                                    .setAuthor({ name: `Ticket Não Avaliado`, iconURL: "https://cdn.discordapp.com/emojis/1247222302970740746.png?size=2048" })
                                    .setDescription(`O usuário ${interaction.user} **NÃO** deu seu feedback do atendimento do ticket`)
                                    .addFields(
                                        {
                                            name: `Avaliação`, value: `\`Nenhuma avaliação.\``
                                        },
                                        {
                                            name: `Data & Horário`, value: `\`⏰\`${tempTicket}`
                                        }
                                    )
                                    .setColor("#313338")
                                    .setFooter({ text: `${interaction.user.username} | ${interaction.user.id}`, iconURL: interaction.user.displayAvatarURL() })
                                    .setTimestamp()
                            ]
                        });
                    };
                    const channelLogsPriv = interaction.client.channels.cache.get(General.get(`channelLogs`));
                    if (channelLogsPriv) {
                        channelLogsPriv.send({
                            embeds: [
                                new EmbedBuilder()
                                    .setAuthor({ name: `Ticket Não Avaliado`, iconURL: "https://cdn.discordapp.com/emojis/1247222302970740746.png?size=2048" })
                                    .setDescription(`O usuário ${interaction.user} não avaliou o ticket.`)
                                    .setColor("#313338")
                                    .setFooter({ text: `${interaction.user.username} | ${interaction.user.id}`, iconURL: interaction.user.displayAvatarURL() })
                                    .setTimestamp()
                            ]
                        });
                    };
                    TicketOpen.delete(`${threadId}`)
                }, 120000);
            }
            await interaction.channel.delete()
        }

        const tempTicket = `<t:${Math.floor(moment().toDate().getTime() / 1000)}:f> (<t:${Math.floor(moment().toDate().getTime() / 1000)}:R>)`;

        if (interaction.isButton() && interaction.customId === "1de3") {General.get("#313338")
            interaction.update({ embeds: [new EmbedBuilder().setAuthor({ name: `Avaliação enviada com êxito, obrigado por avaliar!`, iconURL: "https://cdn.discordapp.com/emojis/1248015639428333599.png?size=2048"}).setColor()], components: [] })
            const channelFeedbacks = interaction.client.channels.cache.get(General.get(`channelFeedbacks`));
            if (channelFeedbacks) {
                await channelFeedbacks.send({
                    embeds: [
                        new EmbedBuilder()
                            .setAuthor({ name: `Ticket Avaliado`, iconURL: "https://cdn.discordapp.com/emojis/1247222312319582260.png?size=2048" })
                            .setDescription(`O usuário ${interaction.user} deu seu feedback do atendimento do ticket`)
                            .addFields(
                                {
                                    name: `Avaliação`, value: `\`⭐ 1/3\` | \`O Atendimento foi péssimo.\``
                                },
                                {
                                    name: `Data & Horário`, value: `\`⏰\`${tempTicket}`
                                }
                            )
                            .setColor("#313338")
                            .setFooter({ text: `${interaction.user.username} | ${interaction.user.id}`, iconURL: interaction.user.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            };
            const channelLogsPriv = interaction.client.channels.cache.get(General.get(`channelLogs`));
            if (channelLogsPriv) {
                await channelLogsPriv.send({
                    embeds: [
                        new EmbedBuilder()
                            .setAuthor({ name: `Ticket Avaliado`, iconURL: "https://cdn.discordapp.com/emojis/1247222312319582260.png?size=2048" })
                            .setDescription(`O usuário ${interaction.user} avaliou o ticket com 1/3 o atendimento foi péssimo.`)
                            .addFields(
                                {
                                    name: `Precisa melhorar?`, value: `\`🔍 Precisa melhorar bastante...\``
                                }
                            )
                            .setColor("#313338")
                            .setFooter({ text: `${interaction.user.username} | ${interaction.user.id}`, iconURL: interaction.user.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            };
        }

        if (interaction.isButton() && interaction.customId === "2de3") {
            interaction.update({ embeds: [new EmbedBuilder().setAuthor({ name: `Avaliação enviada com êxito, obrigado por avaliar!`, iconURL: "https://cdn.discordapp.com/emojis/1248015639428333599.png?size=2048" }).setColor("#313338")], components: [] })
            const channelFeedbacks = interaction.client.channels.cache.get(General.get(`channelFeedbacks`));
            if (channelFeedbacks) {
                await channelFeedbacks.send({
                    embeds: [
                        new EmbedBuilder()
                            .setAuthor({ name: `Ticket Avaliado`, iconURL: "https://cdn.discordapp.com/emojis/1247222312319582260.png?size=2048" })
                            .setDescription(`O usuário ${interaction.user} deu seu feedback do atendimento do ticket`)
                            .addFields(
                                {
                                    name: `Avaliação`, value: `\`⭐ 2/3\` | \`O atendimento não foi muito bom, mas também não foi muito ruim.\``
                                },
                                {
                                    name: `Data & Horário`, value: `\`⏰\`${tempTicket}`
                                }
                            )
                            .setColor("#313338")
                            .setFooter({ text: `${interaction.user.username} | ${interaction.user.id}`, iconURL: interaction.user.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            };
            const channelLogsPriv = interaction.client.channels.cache.get(General.get(`channelLogs`));
            if (channelLogsPriv) {
                await channelLogsPriv.send({
                    embeds: [
                        new EmbedBuilder()
                            .setAuthor({ name: `Ticket Avaliado`, iconURL: "https://cdn.discordapp.com/emojis/1247222312319582260.png?size=2048" })
                            .setDescription(`O usuário ${interaction.user} avaliou o ticket com 2/3 o atendimento não foi muito bom, mas também não foi muito ruim.`)
                            .addFields(
                                {
                                    name: `Precisa melhorar?`, value: `\`🔍 Precisa melhorar um pouco.\``
                                }
                            )
                            .setColor("#313338")
                            .setFooter({ text: `${interaction.user.username} | ${interaction.user.id}`, iconURL: interaction.user.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            };
        }

        if (interaction.isButton() && interaction.customId === "3de3") {
            interaction.update({ embeds: [new EmbedBuilder().setAuthor({ name: `Avaliação enviada com êxito, obrigado por avaliar!`, iconURL: "https://cdn.discordapp.com/emojis/1248015639428333599.png?size=2048" }).setColor("#313338")], components: [] })
            const channelFeedbacks = interaction.client.channels.cache.get(General.get(`channelFeedbacks`));
            if (channelFeedbacks) {
                await channelFeedbacks.send({
                    embeds: [
                        new EmbedBuilder()
                            .setAuthor({ name: `Ticket Avaliado`, iconURL: "https://cdn.discordapp.com/emojis/1247222312319582260.png?size=2048" })
                            .setDescription(`O usuário ${interaction.user} deu seu feedback do atendimento do ticket`)
                            .addFields(
                                {
                                    name: `Avaliação`, value: `\`⭐ 3/3\` | \`O atendimento foi excelente.\``
                                },
                                {
                                    name: `Data & Horário`, value: `\`⏰\`${tempTicket}`
                                }
                            )
                            .setColor("#313338")
                            .setFooter({ text: `${interaction.user.username} | ${interaction.user.id}`, iconURL: interaction.user.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            };
            const channelLogsPriv = interaction.client.channels.cache.get(General.get(`channelLogs`));
            if (channelLogsPriv) {
                await channelLogsPriv.send({
                    embeds: [
                        new EmbedBuilder()
                            .setAuthor({ name: `Ticket Avaliado`, iconURL: "https://cdn.discordapp.com/emojis/1247222312319582260.png?size=2048" })
                            .setDescription(`O usuário ${interaction.user} avaliou o ticket com 3/3 o atendimento foi excelente.`)
                            .addFields(
                                {
                                    name: `Precisa melhorar?`, value: `\`🔍 Não necessita melhorar.\``
                                }
                            )
                            .setColor("#313338")
                            .setFooter({ text: `${interaction.user.username} | ${interaction.user.id}`, iconURL: interaction.user.displayAvatarURL() })
                            .setTimestamp()
                    ]
                });
            };
        }

        if (interaction.isButton() && interaction.customId === "paymentTicket") {
            if (General.get("payments.qrcode") === "") {
                interaction.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setAuthor({ name: `Realizar Pix`, iconURL: "https://cdn.discordapp.com/emojis/1247222426383683666.png?size=2048" })
                            .setFields(
                                {
                                    name: `Chave Pix`, value: `${General.get("payments.pix") === "" ? "\`Não definido.\`" : `\`${General.get("payments.pix")}\``}`
                                },
                                {
                                    name: `Qr Code`, value: `\`Não definido.\``
                                }
                            )
                            .setColor("#313338")
                            .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
                            .setTimestamp()
                    ],
                    ephemeral: true
                })
            } else {
                interaction.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setAuthor({ name: `Realizar Pix`, iconURL: "https://cdn.discordapp.com/emojis/1247222426383683666.png?size=2048" })
                            .setFields(
                                {
                                    name: `Chave Pix`, value: `${General.get("payments.pix") === "" ? "\`Não definido.\`" : `\`${General.get("payments.pix")}\``}`
                                },
                                {
                                    name: `Qr Code`, value: ` `
                                }
                            )
                            .setImage(General.get("payments.qrcode"))
                            .setColor("#313338")
                            .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
                            .setTimestamp()
                    ],
                    ephemeral: true
                })
            }
        }

    }
}