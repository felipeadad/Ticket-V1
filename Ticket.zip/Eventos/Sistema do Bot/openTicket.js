const Discord = require("discord.js");
const { EmbedBuilder, ButtonBuilder, ActionRowBuilder, ApplicationCommandType, isStringSelectMenu, ChannelType } = require("discord.js");
const { General, TicketOpen } = require("../../DataBaseJson/index");
const { owner } = require("../../config.json");
const { panel } = require("../../Functions/panel");
const { gerenciarTicket } = require("../../Functions/gerenciarTicket");
const { gerenciarCanais } = require("../../Functions/gerenciarCanais");
const { Collection } = require('discord.js');
const openTickets = new Collection();
const { ticket } = require("../../Functions/ticket");

module.exports = {
    name: "interactionCreate",
    run: async (interaction, client, message) => {

        if (interaction.isButton() && interaction.customId === "openTicket") {

            if (General.get("sistema") === false) {
                interaction.reply({ embeds: [new EmbedBuilder().setAuthor({ name: `O Sistema se encontra desativado no momento.`, iconURL: "https://cdn.discordapp.com/emojis/1248474741170376704.png?size=2048" }).setColor("#313338")], ephemeral: true });
                return;
            }

            const userId = interaction.user.id;

            
            if (openTickets.has(userId)) {
                interaction.reply({ embeds: [new EmbedBuilder().setAuthor({ name: `Você já possui um ticket aberto.`, iconURL: "https://cdn.discordapp.com/emojis/1248474741170376704.png?size=2048" }).setColor("#313338")], ephemeral: true });
                return;
            }

            const message = interaction.message;
            if (!message.channel.permissionsFor(client.user).has("CreatePrivateThreads")) {
                await interaction.reply({ embeds: [new EmbedBuilder().setAuthor({ name: `Eu não posso abrir um tópico privado.`, iconURL: "https://cdn.discordapp.com/emojis/1248474741170376704.png?size=2048" }).setColor("#313338")], ephemeral: true });
                return;
            }

            const threadName = `ticket・${interaction.user.username}・${interaction.user.id}`;
            const thread = await interaction.channel.threads.create({
                name: threadName,
                type: Discord.ChannelType.PrivateThread,
                reason: 'Needed a separate thread for moderation',
                autoArchiveDuration: 60,
                permissionOverwrites: [
                    {
                        id: interaction.guild.roles.cache.find(role => role.id === General.get("cargoSuportt")),
                        allow: ['VIEW_CHANNEL']
                    }
                ]
            });

            
            openTickets.set(userId, thread.id);

            TicketOpen.set(`${thread.id}`, {
                userOpen: interaction.user.id
            });

            // Adicionando o ID do usuário ao arquivo JSON
            let userTickets = General.get(`userTickets.${interaction.user.id}`) || [];
            userTickets.push(thread.id);
            General.set(`userTickets.${interaction.user.id}`, userTickets);

            interaction.reply({
                embeds: [new EmbedBuilder().setAuthor({ name: `Ticket criado com êxito.`, iconURL: "https://cdn.discordapp.com/emojis/1248015639428333599.png?size=2048" }).setDescription(`**Seu ticket foi criado com sucesso**\n Clique abaixo para ser redirecionado até ele\n`).setColor("#313338")],

                components: [
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                                .setURL(thread.url)
                                .setLabel(`Ir para o Ticket`)
                                .setStyle(5)
                        )
                ], ephemeral: true
            });

            const descriptionTicketDentro = General.get("ticketDentro.description") === "" ? "\`\`\`Descrição não definida.\`\`\`" : `${General.get("ticketDentro.description")}`;

            const ticketAberto = new EmbedBuilder()
                .setAuthor({ name: `${General.get("ticketDentro.title") === "" ? "Ticket" : `${General.get("ticketDentro.title")}`}`, iconURL: client.user.displayAvatarURL() })
                .setDescription(descriptionTicketDentro.replace("#ID", thread.id).replace("#STAFF", `${TicketOpen.get(`${interaction.channel.id}.staff`) === null ? "\`Nenhum staff assumiu ainda.\`" : `<@${TicketOpen.get(`${interaction.channel.id}.staff`)}>`}`).replace("#USER", `<@${TicketOpen.get(`${thread.id}.userOpen`)}>`))
                .setColor("#313338")
                .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
                .setTimestamp();

            if (General.get("ticketDentro.miniatura")) {
                ticketAberto.setThumbnail(`${General.get("ticketDentro.miniatura")}`);
            }

            if (General.get("ticketDentro.banner")) {
                ticketAberto.setImage(`${General.get("ticketDentro.banner")}`);
            }

            const rowTicketAberto = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder().setCustomId(`assumirTicket`).setLabel(`Assumir Ticket`).setEmoji(`1247222480179957800`).setStyle(3),
                    new ButtonBuilder().setCustomId(`pokarUser`).setLabel(`Notificar Usuário`).setEmoji(`1247223445121667155`).setStyle(1)
                );

            if (General.get("payments.sistema") === true) {
                rowTicketAberto.addComponents(
                    new ButtonBuilder()
                        .setCustomId(`paymentTicket`)
                        .setLabel(`Realizar Pix`)
                        .setEmoji(`1247222426383683666`)
                        .setStyle(1)
                        .setDisabled(General.get("payments.pix") && General.get("payments.qrcode") === "" ? false : true)
                );
            }

            rowTicketAberto.addComponents(
                new ButtonBuilder().setCustomId(`fecharTicket`).setEmoji(`1247222358733885550`).setStyle(2)
            );

            const cargoPerm = General.get("cargoSuportt");
            const contentTopic = cargoPerm ? `${interaction.user} | <@&${cargoPerm}>` : `${interaction.user}`;
            await sendMessage(thread, {
                content: contentTopic,
                embeds: [ticketAberto],
                components: [rowTicketAberto]
            });
        }
        
        async function sendMessage(channel, content) {
            await channel.send(content);
        }
    }
};
