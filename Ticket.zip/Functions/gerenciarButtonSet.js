const { ActionRowBuilder, ButtonBuilder, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ApplicationCommand, ApplicationCommandType, SelectMenuBuilder, StringSelectMenuBuilder } = require("discord.js")
const { owner } = require("../config.json")
const { General } = require("../DataBaseJson/index")

async function gerenciarButtonSet(client, interaction) {
    interaction.update({
        content: ``,
        embeds: [
            new EmbedBuilder()
            .setAuthor({ name: `Red Apps Ticket`, iconURL: client.user.displayAvatarURL() })
            .setDescription(`- **Selecione abaixo qual opção do botão você deseja configurar:**`)
            .addFields(
                {
                    name: `Nome`, value: `${General.get("ticket.button.name") === "" ? "\`Não definido.\`" : `\`${General.get("ticket.button.name")}\``}`
                },
                {
                    name: `Cor`, value: `${General.get("ticket.button.color") === "" ? "\`Não definido.\`" : `\`${General.get("ticket.button.color")}\``}`
                },
                {
                    name: `Emoji`, value: `${General.get("ticket.button.emoji") === "" ? "\`Não definido.\`" : `\`${General.get("ticket.button.emoji")}\``}`
                },
            )
            .setColor("#313338")
            .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
            .setTimestamp()
        ],
        components: [
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder().setCustomId(`gerenciarButtonName`).setLabel(`Alterar Nome`).setEmoji(`1247222355126915185`).setStyle(1),
                new ButtonBuilder().setCustomId(`gerenciarButtonColor`).setLabel(`Alterar Cor`).setEmoji(`1247222355126915185`).setStyle(1),
                new ButtonBuilder().setCustomId(`gerenciarButtonEmoji`).setLabel(`Alterar Emoji`).setEmoji(`1247222355126915185`).setStyle(1),
                new ButtonBuilder().setCustomId(`voltarTicketSet`).setLabel(`Voltar`).setEmoji(`1247222436533899264`).setStyle(2)
            )
        ],
        ephemeral: true
    })
}

module.exports = {
    gerenciarButtonSet
}