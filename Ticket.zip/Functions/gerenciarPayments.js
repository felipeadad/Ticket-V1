const { ActionRowBuilder, ButtonBuilder, EmbedBuilder } = require("discord.js");
const { General } = require("../DataBaseJson/index");

async function gerenciarPayments(client, interaction) {
    try {
        await interaction.update({
            embeds: [
                new EmbedBuilder()
                    .setAuthor({ name: `Red Apps Ticket`, iconURL: client.user.displayAvatarURL() })
                    .setDescription(`- **Selecione abaixo qual opção de pagamento você deseja configurar:**`)
                    .addFields(
                        { name: `Chave Pix`, value: `${General.get("payments.sistema") === true ? "\`Ligado\`" : `\`Desligado\``}`, inline: true },
                        { name: `Chave Pix`, value: `${General.get("payments.pix") === "" ? "\`Não definido.\`" : `\`${General.get("payments.pix")}\``}`, inline: true },
                        { name: `Qr Code`, value: `${General.get("payments.qrcode") === "" ? "\`Não definido.\`" : `**[Clique Aqui](${General.get("payments.qrcode")})**`}`, inline: true }
                    )
                    .setColor("#313338")
                    .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
                    .setTimestamp()
            ],
            components: [
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId(`changePaymentsOnOff`).setLabel(General.get("payments.sistema") === true ? "Sistema Ligado" : "Sistema Desligado").setEmoji(`1247222293407727709`).setStyle(General.get("payments.sistema") === true ? 3 : 4),
                    new ButtonBuilder().setCustomId(`changePix`).setLabel(`Chave Pix`).setEmoji(`1247222355126915185`).setStyle(1),
                    new ButtonBuilder().setCustomId(`changeQrCode`).setLabel(`Qr Code`).setEmoji(`1247222355126915185`).setStyle(1),
                    new ButtonBuilder().setCustomId(`Acesstoken`).setLabel(`Mercado Pago (V2)`).setEmoji(`1219640877723549726`).setStyle(1).setDisabled(true),
                    new ButtonBuilder().setCustomId(`voltarPanel`).setLabel(`Voltar`).setEmoji(`1247222436533899264`).setStyle(2)
                )
            ],
            ephemeral: true
        });
    } catch (error) {
        console.error("[LOG] Error updating interaction:", error);
    }
}

module.exports = {
    gerenciarPayments
};
