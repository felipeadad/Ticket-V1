const { ActionRowBuilder, ButtonBuilder, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ApplicationCommand, ApplicationCommandType, SelectMenuBuilder, StringSelectMenuBuilder } = require("discord.js")
const { owner } = require("../config.json")
const { General } = require("../DataBaseJson/index")

async function gerenciarTicket(client, interaction) {
    interaction.update({
        embeds: [
            new EmbedBuilder()
            .setAuthor({ name: `Red Apps Ticket`, iconURL: client.user.displayAvatarURL() })
            .setDescription(`- **Selecione abaixo qual opção do ticket você deseja configurar:**`)
            .setColor("#313338")
            .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
            .setTimestamp()
        ],
        components: [
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder().setCustomId(`changeTicketSet`).setLabel(`Embed Set`).setEmoji(`1248436294552518727`).setStyle(1),
                new ButtonBuilder().setCustomId(`changeTicketAberto`).setLabel(`Embed Aberto`).setEmoji(`1248436294552518727`).setStyle(1),
                new ButtonBuilder().setCustomId(`changeTicketEmojis`).setLabel(`Horários de Atendimento (V2)`).setEmoji(`1247222291578749001`).setStyle(1).setDisabled(true),
                new ButtonBuilder().setCustomId(`voltarPanel`).setLabel(`Voltar`).setEmoji(`1247222436533899264`).setStyle(2)
            )
        ],
        ephemeral: true
    })
}

module.exports = {
    gerenciarTicket
}