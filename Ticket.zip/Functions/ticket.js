const { Collection } = require('discord.js');

const openTickets = new Collection();

function checkOpenTicket(userId) {
    return openTickets.some(ticket => ticket.userId === userId);
}

function openTicket(threadId, userId) {
    openTickets.set(threadId, { userId });
}

function closeTicket(threadId) {
    openTickets.delete(threadId);
}

module.exports = { checkOpenTicket, openTicket, closeTicket };
